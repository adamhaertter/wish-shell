void del_newline(char* str);
char** split_array(char* str);