void wish_exit(char** args);
void wish_path(char **args, char **path);
void wish_cd(char **args);